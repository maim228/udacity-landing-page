# Landing Page 
this is the landing page project readme

## Table of content:

 - Languages used
 - Installation 
 - Most important functions

### Languages used:

 - HTML
 (index.html)
 - CSS
 (css/styles.css)
 - Javascript
 ( js/app.js)
 
 ### Installation:
 
 Open index.html file and make sure css and js folders in same folder of index.html

### Most important functions:

 - createNav()
 - getBoundingClientRect()
 - buildNav()
 - addictive
 - removeActive
 - sectionActivison 
